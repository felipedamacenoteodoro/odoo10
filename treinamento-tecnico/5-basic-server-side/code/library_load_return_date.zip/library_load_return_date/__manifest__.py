# -*- coding: utf-8 -*-
{
    'name': "Library Load Return Date",
    'depends': ['base', 'library.book'],
}
