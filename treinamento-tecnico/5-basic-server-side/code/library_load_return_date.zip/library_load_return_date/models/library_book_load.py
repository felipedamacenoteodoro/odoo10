# -*- coding: utf-8 -*-

import sys
from odoo import models, fields, api

reload(sys)
sys.setdefaultencoding("utf-8")

class LibraryBook(models.Model):
    _inherit = 'library.book'
    expected_return_date = fields.Date('Due for')

    def _compute_age(self, partner, contacts):
        super(LibraryBook, self)._compute_age()

        for book in self.filtered('date_release'):
            if book.age_days == 0:
                book.age_days = -1


class LibraryMember(models.Model):
    _inherit = 'library.member'
    loan_duration = fields.Integer('Load duration',
                                   default=15,
                                   required=True,
                                   )