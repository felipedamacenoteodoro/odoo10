# -*- coding: utf-8 -*-

from odoo import models, fields

class LibraryBookLoad(models.Models):
    _inherit = 'library.book'
